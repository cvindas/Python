# Dependencies
to install socketio: `pip3 install flask-socketio`
