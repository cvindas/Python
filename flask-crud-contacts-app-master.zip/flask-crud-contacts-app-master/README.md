# Screenshot
![](docs/screenshot.png)

# install dependencies
- pip install flask
- pip install flask-mysqldb

# issues
- sudo apt-get install libmysqlclient-dev
