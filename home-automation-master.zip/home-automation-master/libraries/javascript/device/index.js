const Device = require("./Device");
const store = require("./store");
const updateDependencies = require("./updateDependencies");

exports = module.exports = { Device, store, updateDependencies };
