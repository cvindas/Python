CONTROLLER_NAME = 'service.controller.dmx'
