API_GATEWAY = 'http://192.168.1.100:7005'
REDIS = {
    'host': '192.168.1.100',
    'port': 6379,
}
