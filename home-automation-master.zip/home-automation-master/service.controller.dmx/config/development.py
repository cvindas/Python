API_GATEWAY = 'http://service.api-gateway'
REDIS = {
    'host': 'redis',
    'port': 6379,
}
