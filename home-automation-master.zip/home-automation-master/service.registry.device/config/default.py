DATABASE = 'data/devices.db'
