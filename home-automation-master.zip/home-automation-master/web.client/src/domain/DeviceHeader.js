export default class DeviceHeader {
  constructor(identifier, name, deviceType, controllerName) {
    this.identifier = identifier;
    this.name = name;
    this.deviceType = deviceType;
    this.controllerName = controllerName;
  }
}
