<template>
  <BaseLayout
    done
    class="raw-json-viewer"
  >
    <template slot="heading" />
    <template slot="content" />
  </BaseLayout>
</template>

<script>
export default {
  name: 'RawJsonViewer',
};
</script>
